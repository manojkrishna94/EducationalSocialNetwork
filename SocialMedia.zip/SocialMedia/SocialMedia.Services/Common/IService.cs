﻿namespace SocialMedia.Services.Common
{
    public interface IService
    {
    }
}
