﻿namespace SocialMedia.Web.Models
{
    public class ImageViewModel
    {
        public int ImageId { get; set; }
        public string Base64Image { get; set; }
    }
}
